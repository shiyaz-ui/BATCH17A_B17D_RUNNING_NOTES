

provider "aws" {
  
  region = "us-east-1"

}

# Ec2 Instance

resource "aws_instance" "prod" {
  ami = "ami-02dfbd4ff395f2a1b"
  instance_type = "t2.micro"
  key_name = "ramanikey"
  count = 1

    tags = {
        Name = "Madhukiran Server"
    }

}