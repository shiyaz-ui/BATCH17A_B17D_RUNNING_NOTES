

variable "vpc_cidr" {
  
  description = "Vpc cidr "
 # default = "10.81.0.0/16"
  type = string
}


variable "subnet_cidr" {
  
  description = "Subnet cidr "
#  default = "10.81.3.0/24"
  
}

variable "eni_pvtip" {
  description = "Ip for created elastic NIC "
  default = ["10.81.3.33"]
}

variable "ami" {
  description = "AMI for the EC2 instance "
  default = "ami-02dfbd4ff395f2a1b"
}

variable "instance_type" {
  description = "Instance type for the EC2 instance "
  default = "t2.micro"
}

variable "key_name" {
  description = "Key pair name for the instance "
  default = "batch17a"
}

variable "env_server" {
  description = "Environemnt name for the fb server"
  default = "fb-Server"
  type = string
}

variable "server_count" {
  description = "Number of instances to launch"
  default = 1
  type = number
}