

ami_id = "ami-0b6c6ebed2801a5cb"
instance_type = "t2.micro"
key_name = "ramanikey"
#server_env = "SBOX Server"